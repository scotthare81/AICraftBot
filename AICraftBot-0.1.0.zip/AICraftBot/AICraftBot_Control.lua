local selectedBots = {}
local selectedDeployBots = {}

local activeRoster = {}
local availableRoster = {}

local visibleRows = 12
local rowHeight = 22

local deploymentQueue = {}
local deploymentRunning = false

local function PrintMessage(text)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99AICraftBot:|r " .. text)
end

local function CountSelected(selection)
    local count = 0

    for _, selected in pairs(selection) do
        if selected then
            count = count + 1
        end
    end

    return count
end

local function IsGroupMember(name)
    local playerName = UnitName("player")

    if name == playerName then
        return true
    end

    if GetNumRaidMembers() > 0 then
        local i

        for i = 1, GetNumRaidMembers() do
            if UnitName("raid" .. i) == name then
                return true
            end
        end
    else
        local i

        for i = 1, GetNumPartyMembers() do
            if UnitName("party" .. i) == name then
                return true
            end
        end
    end

    return false
end

local function FindGroupUnit(name)
    if GetNumRaidMembers() > 0 then
        local i

        for i = 1, GetNumRaidMembers() do
            local unit = "raid" .. i

            if UnitName(unit) == name then
                return unit
            end
        end
    else
        local i

        for i = 1, GetNumPartyMembers() do
            local unit = "party" .. i

            if UnitName(unit) == name then
                return unit
            end
        end
    end

    return nil
end

local function BuildActiveRoster()
    activeRoster = {}

    local playerName = UnitName("player")

    if GetNumRaidMembers() > 0 then
        local i

        for i = 1, GetNumRaidMembers() do
            local unit = "raid" .. i
            local name = UnitName(unit)

            if name and name ~= playerName then
                local _, class = UnitClass(unit)

                table.insert(activeRoster, {
                    name = name,
                    class = class or "UNKNOWN",
                    unit = unit
                })
            end
        end
    else
        local i

        for i = 1, GetNumPartyMembers() do
            local unit = "party" .. i
            local name = UnitName(unit)

            if name and name ~= playerName then
                local _, class = UnitClass(unit)

                table.insert(activeRoster, {
                    name = name,
                    class = class or "UNKNOWN",
                    unit = unit
                })
            end
        end
    end

    table.sort(activeRoster, function(a, b)
        return a.name < b.name
    end)
end

local function BuildAvailableRoster()
    availableRoster = {}

    local playerName = UnitName("player")

    if not botTable then
        return
    end

    for name, bot in pairs(botTable) do
        if type(name) == "string"
            and name ~= ""
            and name ~= playerName
            and type(bot) == "table" then

            local class = bot["class"] or "UNKNOWN"

            table.insert(availableRoster, {
                name = name,
                class = string.upper(class),
                online = bot["online"] == true
            })
        end
    end

    table.sort(availableRoster, function(a, b)
        return a.name < b.name
    end)
end

local function RequestBotList()
    SendChatMessage(".bot list", "SAY")
end

local function SendToSelected(command)
    local count = 0

    for name, selected in pairs(selectedBots) do
        if selected then
            SendChatMessage(command, "WHISPER", nil, name)
            count = count + 1
        end
    end

    if count == 0 then
        PrintMessage("Select at least one active bot.")
        return
    end

    PrintMessage(command .. " -> " .. count .. " bot(s)")
end

local waitFrame = CreateFrame("Frame")
local waitTasks = {}

waitFrame:SetScript("OnUpdate", function()
    local elapsed = arg1
    local i

    for i = table.getn(waitTasks), 1, -1 do
        local task = waitTasks[i]
        task.remaining = task.remaining - elapsed

        if task.remaining <= 0 then
            table.remove(waitTasks, i)
            task.callback()
        end
    end
end)

local function Wait(seconds, callback)
    table.insert(waitTasks, {
        remaining = seconds,
        callback = callback
    })
end

local function DeployBot(name, number, total)
    local delay = (number - 1) * 1.5

    Wait(delay, function()
        PrintMessage("Logging in " .. name .. " (" .. number .. "/" .. total .. ")")
        SendChatMessage(".bot add " .. name, "SAY")
    end)

    Wait(delay + 1.0, function()
        if number == total then
            deploymentRunning = false
            PrintMessage("Login queue complete.")

            Wait(1.0, function()
                RequestBotList()
            end)
        end
    end)
end

local function DeploySelected()
    if deploymentRunning then
        PrintMessage("A login queue is already running.")
        return
    end

    deploymentQueue = {}

    for name, selected in pairs(selectedDeployBots) do
        local bot = botTable and botTable[name]

        if selected and bot and not bot["online"] then
            table.insert(deploymentQueue, name)
        end
    end

    table.sort(deploymentQueue)

    local total = table.getn(deploymentQueue)

    if total == 0 then
        PrintMessage("Select at least one offline bot.")
        return
    end

    deploymentRunning = true
    PrintMessage("Logging in " .. total .. " bot(s).")

    local i

    for i = 1, total do
        DeployBot(deploymentQueue[i], i, total)
    end
end

local classColours = {
    WARRIOR = { 0.78, 0.61, 0.43 },
    MAGE = { 0.41, 0.80, 0.94 },
    ROGUE = { 1.00, 0.96, 0.41 },
    DRUID = { 1.00, 0.49, 0.04 },
    HUNTER = { 0.67, 0.83, 0.45 },
    SHAMAN = { 0.14, 0.35, 1.00 },
    PRIEST = { 1.00, 1.00, 1.00 },
    WARLOCK = { 0.58, 0.51, 0.79 },
    PALADIN = { 0.96, 0.55, 0.73 },
    UNKNOWN = { 0.80, 0.80, 0.80 }
}

local function CreateActionButton(parent, text, x, y, width, command)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetWidth(width or 95)
    button:SetHeight(24)
    button:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    button:SetText(text)
    button.command = command

    button:SetScript("OnClick", function()
        SendToSelected(this.command)
    end)

    return button
end

local frame = CreateFrame("Frame", "AICraftBotControlFrame", UIParent)
frame:SetWidth(590)
frame:SetHeight(465)
frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")

frame:SetScript("OnDragStart", function()
    this:StartMoving()
end)

frame:SetScript("OnDragStop", function()
    this:StopMovingOrSizing()
end)

frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true,
    tileSize = 32,
    edgeSize = 32,
    insets = {
        left = 11,
        right = 12,
        top = 12,
        bottom = 11
    }
})

frame:Hide()

local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
title:SetPoint("TOP", frame, "TOP", 0, -18)
title:SetText("AICraft Bot Control")

local closeButton = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
closeButton:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -5, -5)

local controlPanel = CreateFrame("Frame", nil, frame)
controlPanel:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, -60)
controlPanel:SetWidth(590)
controlPanel:SetHeight(395)

local deployPanel = CreateFrame("Frame", nil, frame)
deployPanel:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, -60)
deployPanel:SetWidth(590)
deployPanel:SetHeight(395)
deployPanel:Hide()

local controlTab = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
controlTab:SetWidth(110)
controlTab:SetHeight(25)
controlTab:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -42)
controlTab:SetText("Control")

local deployTab = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
deployTab:SetWidth(110)
deployTab:SetHeight(25)
deployTab:SetPoint("LEFT", controlTab, "RIGHT", 4, 0)
deployTab:SetText("Deploy")

local function ShowControlTab()
    deployPanel:Hide()
    controlPanel:Show()
end

local function ShowDeployTab()
    controlPanel:Hide()
    deployPanel:Show()
    RequestBotList()

    Wait(0.8, function()
        BuildAvailableRoster()

        if UpdateDeployRows then
            UpdateDeployRows()
        end
    end)
end

controlTab:SetScript("OnClick", ShowControlTab)
deployTab:SetScript("OnClick", ShowDeployTab)

-- CONTROL TAB

local activeTitle = controlPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
activeTitle:SetPoint("TOPLEFT", controlPanel, "TOPLEFT", 24, -12)
activeTitle:SetText("Active Bots")

local activeSelectedLabel = controlPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
activeSelectedLabel:SetPoint("TOPLEFT", controlPanel, "TOPLEFT", 135, -13)
activeSelectedLabel:SetText("0 selected")

local activePanel = CreateFrame("Frame", nil, controlPanel)
activePanel:SetPoint("TOPLEFT", controlPanel, "TOPLEFT", 20, -34)
activePanel:SetWidth(200)
activePanel:SetHeight(280)

activePanel:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true,
    tileSize = 16,
    edgeSize = 12,
    insets = {
        left = 3,
        right = 3,
        top = 3,
        bottom = 3
    }
})

activePanel:SetBackdropColor(0, 0, 0, 0.75)

local activeScroll = CreateFrame(
    "ScrollFrame",
    "AICraftBotActiveScrollFrame",
    activePanel,
    "FauxScrollFrameTemplate"
)

activeScroll:SetPoint("TOPLEFT", activePanel, "TOPLEFT", 5, -5)
activeScroll:SetPoint("BOTTOMRIGHT", activePanel, "BOTTOMRIGHT", -25, 5)

local activeRows = {}

local function UpdateActiveRows()
    local offset = FauxScrollFrame_GetOffset(activeScroll)
    local i

    for i = 1, visibleRows do
        local row = activeRows[i]
        local bot = activeRoster[offset + i]

        if bot then
            row.botName = bot.name
            row.check:SetChecked(selectedBots[bot.name] == true)
            row.text:SetText(bot.name)

            local colour = classColours[bot.class] or classColours.UNKNOWN
            row.text:SetTextColor(colour[1], colour[2], colour[3])
            row:Show()
        else
            row.botName = nil
            row:Hide()
        end
    end

    FauxScrollFrame_Update(
        activeScroll,
        table.getn(activeRoster),
        visibleRows,
        rowHeight
    )

    activeSelectedLabel:SetText(CountSelected(selectedBots) .. " selected")
end

local i

for i = 1, visibleRows do
    local row = CreateFrame("Button", nil, activePanel)
    row:SetWidth(160)
    row:SetHeight(rowHeight)
    row:SetPoint("TOPLEFT", activePanel, "TOPLEFT", 6, -5 - ((i - 1) * rowHeight))

    row.check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
    row.check:SetWidth(20)
    row.check:SetHeight(20)
    row.check:SetPoint("LEFT", row, "LEFT", 0, 0)

    row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.text:SetPoint("LEFT", row.check, "RIGHT", 2, 0)

    row.check.ownerRow = row

    row.check:SetScript("OnClick", function()
        local owner = this.ownerRow

        if owner and owner.botName then
            if this:GetChecked() then
                selectedBots[owner.botName] = true
            else
                selectedBots[owner.botName] = nil
            end

            activeSelectedLabel:SetText(CountSelected(selectedBots) .. " selected")
        end
    end)

    row:SetScript("OnClick", function()
        if this.botName then
            local selected = not selectedBots[this.botName]
            selectedBots[this.botName] = selected or nil
            this.check:SetChecked(selected)
            activeSelectedLabel:SetText(CountSelected(selectedBots) .. " selected")
        end
    end)

    activeRows[i] = row
end

activeScroll:SetScript("OnVerticalScroll", function()
    FauxScrollFrame_OnVerticalScroll(arg1, rowHeight, UpdateActiveRows)
end)

local selectAllActive = CreateFrame("Button", nil, controlPanel, "UIPanelButtonTemplate")
selectAllActive:SetWidth(88)
selectAllActive:SetHeight(22)
selectAllActive:SetPoint("TOPLEFT", controlPanel, "TOPLEFT", 24, -325)
selectAllActive:SetText("Select All")

selectAllActive:SetScript("OnClick", function()
    local index

    for index = 1, table.getn(activeRoster) do
        selectedBots[activeRoster[index].name] = true
    end

    UpdateActiveRows()
end)

local clearActive = CreateFrame("Button", nil, controlPanel, "UIPanelButtonTemplate")
clearActive:SetWidth(88)
clearActive:SetHeight(22)
clearActive:SetPoint("LEFT", selectAllActive, "RIGHT", 8, 0)
clearActive:SetText("Clear")

clearActive:SetScript("OnClick", function()
    selectedBots = {}
    UpdateActiveRows()
end)

local refreshActive = CreateFrame("Button", nil, controlPanel, "UIPanelButtonTemplate")
refreshActive:SetWidth(184)
refreshActive:SetHeight(22)
refreshActive:SetPoint("TOPLEFT", controlPanel, "TOPLEFT", 24, -355)
refreshActive:SetText("Refresh Group")

refreshActive:SetScript("OnClick", function()
    BuildActiveRoster()
    UpdateActiveRows()
end)

local movementTitle = controlPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
movementTitle:SetPoint("TOPLEFT", controlPanel, "TOPLEFT", 245, -16)
movementTitle:SetText("Movement")

CreateActionButton(controlPanel, "Follow", 245, -40, 100, "follow")
CreateActionButton(controlPanel, "Stay", 350, -40, 100, "stay")
CreateActionButton(controlPanel, "Guard", 455, -40, 100, "guard")

CreateActionButton(controlPanel, "Free", 245, -70, 100, "free")
CreateActionButton(controlPanel, "Flee", 350, -70, 100, "flee")
CreateActionButton(controlPanel, "Return", 455, -70, 100, "return")

local combatTitle = controlPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
combatTitle:SetPoint("TOPLEFT", controlPanel, "TOPLEFT", 245, -112)
combatTitle:SetText("Combat")

CreateActionButton(controlPanel, "Attack", 245, -136, 100, "attack")
CreateActionButton(controlPanel, "Pull", 350, -136, 100, "pull")
CreateActionButton(controlPanel, "Tank Attack", 455, -136, 100, "tank attack")

CreateActionButton(controlPanel, "No Delay", 245, -166, 100, "wait for attack time 0")
CreateActionButton(controlPanel, "2 sec Delay", 350, -166, 100, "wait for attack time 2")
CreateActionButton(controlPanel, "5 sec Delay", 455, -166, 100, "wait for attack time 5")

local supportTitle = controlPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
supportTitle:SetPoint("TOPLEFT", controlPanel, "TOPLEFT", 245, -208)
supportTitle:SetText("Support")

CreateActionButton(controlPanel, "Repair", 245, -232, 100, "repair")
CreateActionButton(controlPanel, "Ready Check", 350, -232, 100, "ready check")
CreateActionButton(controlPanel, "Buff", 455, -232, 100, "buff")

CreateActionButton(controlPanel, "Save Mana", 245, -262, 100, "save mana")
CreateActionButton(controlPanel, "Revive", 350, -262, 100, "revive target")
CreateActionButton(controlPanel, "Reset AI", 455, -262, 100, "reset ai soft")

local strategyTitle = controlPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
strategyTitle:SetPoint("TOPLEFT", controlPanel, "TOPLEFT", 245, -304)
strategyTitle:SetText("Combat Style")

CreateActionButton(controlPanel, "AoE On", 245, -328, 100, "co +aoe")
CreateActionButton(controlPanel, "AoE Off", 350, -328, 100, "co -aoe")
CreateActionButton(controlPanel, "Max DPS", 455, -328, 100, "max dps")

-- DEPLOY TAB

local deployTitle = deployPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
deployTitle:SetPoint("TOPLEFT", deployPanel, "TOPLEFT", 24, -12)
deployTitle:SetText("Available Bots")

local deploySelectedLabel = deployPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
deploySelectedLabel:SetPoint("TOPLEFT", deployPanel, "TOPLEFT", 145, -13)
deploySelectedLabel:SetText("0 selected")

local availablePanel = CreateFrame("Frame", nil, deployPanel)
availablePanel:SetPoint("TOPLEFT", deployPanel, "TOPLEFT", 20, -34)
availablePanel:SetWidth(260)
availablePanel:SetHeight(300)

availablePanel:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true,
    tileSize = 16,
    edgeSize = 12,
    insets = {
        left = 3,
        right = 3,
        top = 3,
        bottom = 3
    }
})

availablePanel:SetBackdropColor(0, 0, 0, 0.75)

local deployScroll = CreateFrame(
    "ScrollFrame",
    "AICraftBotDeployScrollFrame",
    availablePanel,
    "FauxScrollFrameTemplate"
)

deployScroll:SetPoint("TOPLEFT", availablePanel, "TOPLEFT", 5, -5)
deployScroll:SetPoint("BOTTOMRIGHT", availablePanel, "BOTTOMRIGHT", -25, 5)

local deployRows = {}

function UpdateDeployRows()
    local offset = FauxScrollFrame_GetOffset(deployScroll)
    local i

    for i = 1, visibleRows do
        local row = deployRows[i]
        local bot = availableRoster[offset + i]

        if bot then
            row.botName = bot.name
            row.check:SetChecked(selectedDeployBots[bot.name] == true)
            row.text:SetText(bot.name)

            if bot.online then
                row.status:SetText("|cff33ff33Online|r")
                row.check:Disable()
                selectedDeployBots[bot.name] = nil
            else
                row.status:SetText("|cffaaaaaaOffline|r")
                row.check:Enable()
            end

            local colour = classColours[bot.class] or classColours.UNKNOWN
            row.text:SetTextColor(colour[1], colour[2], colour[3])
            row:Show()
        else
            row.botName = nil
            row:Hide()
        end
    end

    FauxScrollFrame_Update(
        deployScroll,
        table.getn(availableRoster),
        visibleRows,
        rowHeight
    )

    deploySelectedLabel:SetText(CountSelected(selectedDeployBots) .. " selected")
end

for i = 1, visibleRows do
    local row = CreateFrame("Button", nil, availablePanel)
    row:SetWidth(220)
    row:SetHeight(rowHeight)
    row:SetPoint("TOPLEFT", availablePanel, "TOPLEFT", 6, -5 - ((i - 1) * rowHeight))

    row.check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
    row.check:SetWidth(20)
    row.check:SetHeight(20)
    row.check:SetPoint("LEFT", row, "LEFT", 0, 0)

    row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.text:SetPoint("LEFT", row.check, "RIGHT", 2, 0)

    row.status = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.status:SetPoint("RIGHT", row, "RIGHT", -4, 0)

    row.check.ownerRow = row

    row.check:SetScript("OnClick", function()
        local owner = this.ownerRow

        if owner and owner.botName then
            if this:GetChecked() then
                selectedDeployBots[owner.botName] = true
            else
                selectedDeployBots[owner.botName] = nil
            end

            deploySelectedLabel:SetText(CountSelected(selectedDeployBots) .. " selected")
        end
    end)

    deployRows[i] = row
end

deployScroll:SetScript("OnVerticalScroll", function()
    FauxScrollFrame_OnVerticalScroll(arg1, rowHeight, UpdateDeployRows)
end)

local selectAllDeploy = CreateFrame("Button", nil, deployPanel, "UIPanelButtonTemplate")
selectAllDeploy:SetWidth(105)
selectAllDeploy:SetHeight(24)
selectAllDeploy:SetPoint("TOPLEFT", deployPanel, "TOPLEFT", 305, -42)
selectAllDeploy:SetText("Select Offline")

selectAllDeploy:SetScript("OnClick", function()
    local index

    for index = 1, table.getn(availableRoster) do
        local bot = availableRoster[index]

        if not bot.online then
            selectedDeployBots[bot.name] = true
        end
    end

    UpdateDeployRows()
end)

local clearDeploy = CreateFrame("Button", nil, deployPanel, "UIPanelButtonTemplate")
clearDeploy:SetWidth(105)
clearDeploy:SetHeight(24)
clearDeploy:SetPoint("LEFT", selectAllDeploy, "RIGHT", 8, 0)
clearDeploy:SetText("Clear")

clearDeploy:SetScript("OnClick", function()
    selectedDeployBots = {}
    UpdateDeployRows()
end)

local refreshDeploy = CreateFrame("Button", nil, deployPanel, "UIPanelButtonTemplate")
refreshDeploy:SetWidth(218)
refreshDeploy:SetHeight(24)
refreshDeploy:SetPoint("TOPLEFT", deployPanel, "TOPLEFT", 305, -76)
refreshDeploy:SetText("Refresh Bot List")

refreshDeploy:SetScript("OnClick", function()
    RequestBotList()

    Wait(0.8, function()
        BuildAvailableRoster()
        UpdateDeployRows()
    end)
end)

local deployInfo = deployPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
deployInfo:SetWidth(235)
deployInfo:SetJustifyH("LEFT")
deployInfo:SetJustifyV("TOP")
deployInfo:SetPoint("TOPLEFT", deployPanel, "TOPLEFT", 305, -125)
deployInfo:SetText(
    "Deploy Selected currently performs one reliable step:\n\n" ..
    "1. Log each selected offline bot into the world\n\n" ..
    "Online status comes directly from the server bot list.\n\n" ..
    "Invite, summon and prepare will be added after login is verified."
)

local deployButton = CreateFrame("Button", nil, deployPanel, "UIPanelButtonTemplate")
deployButton:SetWidth(218)
deployButton:SetHeight(34)
deployButton:SetPoint("TOPLEFT", deployPanel, "TOPLEFT", 305, -275)
deployButton:SetText("Login Selected")

deployButton:SetScript("OnClick", DeploySelected)

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("PARTY_MEMBERS_CHANGED")
eventFrame:RegisterEvent("RAID_ROSTER_UPDATE")

eventFrame:SetScript("OnEvent", function()
    BuildActiveRoster()
    BuildAvailableRoster()
    UpdateActiveRows()
    UpdateDeployRows()
end)

local function ToggleControlFrame()
    if frame:IsVisible() then
        frame:Hide()
    else
        BuildActiveRoster()
        RequestBotList()

        Wait(0.5, function()
            BuildAvailableRoster()
            UpdateActiveRows()
            UpdateDeployRows()
        end)

        frame:Show()
    end
end

SLASH_AICRAFTCONTROL1 = "/aic"
SLASH_AICRAFTCONTROL2 = "/aicontrol"
SLASH_AICRAFTCONTROL3 = "/aibot"
SLASH_AICRAFTCONTROL4 = "/aibots"

SlashCmdList["AICRAFTCONTROL"] = ToggleControlFrame

PrintMessage("Control and deployment tabs loaded. Use /aibot")
